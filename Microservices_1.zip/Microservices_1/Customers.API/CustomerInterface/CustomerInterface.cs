﻿using Customers.API.Models;

namespace Customers.API.CustomerInterface
{
	public interface CustomerInterface
	{
		
	}
}
