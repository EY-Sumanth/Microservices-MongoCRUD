﻿namespace Customers.API.CustomerRepo
{
	public class CustomerRepository
	{
	}
}
