﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Products.API.Models;

namespace Products.API.Controllers
{
	
	[ApiController]
	[Route("api/Products")]
	public class ProductsController : ControllerBase
	{
		private readonly ProductMSContext _context;

		public ProductsController(ProductMSContext context)
		{
			_context = context;
		}

		// GET: api/products
		[HttpGet]
		public async Task<ActionResult<IEnumerable<TProduct>>> GetProducts()
		{
			return await _context.TProducts.ToListAsync();
		}

		// GET: api/products/5
		[HttpGet("{id}")]
		public async Task<ActionResult<TProduct>> GetProduct(int id)
		{
			var product = await _context.TProducts.FindAsync(id);

			if (product == null)
			{
				return NotFound();
			}

			return product;
		}

		// POST: api/products
		[HttpPost]
		public async Task<ActionResult<TProduct>> PostProduct(TProduct product)
		{
			_context.TProducts.Add(product);
			await _context.SaveChangesAsync();

			return CreatedAtAction(nameof(GetProduct), new { id = product.ProductId }, product);
		}

		// PUT: api/products/5
		[HttpPut("{id}")]
		public async Task<IActionResult> PutProduct(int id, TProduct product)
		{
			if (id != product.ProductId)
			{
				return BadRequest();
			}

			_context.Entry(product).State = EntityState.Modified;

			try
			{
				await _context.SaveChangesAsync();
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!ProductExists(id))
				{
					return NotFound();
				}
				else
				{
					throw;
				}
			}

			return NoContent();
		}

		// DELETE: api/products/5
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteProduct(int id)
		{
			var product = await _context.TProducts.FindAsync(id);
			if (product == null)
			{
				return NotFound();
			}

			_context.TProducts.Remove(product);
			await _context.SaveChangesAsync();

			return NoContent();
		}

		private bool ProductExists(int id)
		{
			return _context.TProducts.Any(e => e.ProductId == id);
		}
	}
}
