﻿using System;
using System.Collections.Generic;

namespace CustomerAPI.Models
{
    public partial class TCustomer
    {
        public int CustomerId { get; set; }
        public string? CustomerName { get; set; }
        public string? CustomerAddress { get; set; }
        public int? CustomerNumber { get; set; }
    }
}
