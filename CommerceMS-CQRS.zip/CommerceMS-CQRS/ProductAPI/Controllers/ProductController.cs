﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductAPI.Models;

namespace ProductAPI.Controllers
{
	
		[ApiController]
		[Route("api/Product")]
		public class TProductController : ControllerBase
		{
			private readonly CommerceMSContext _context;

			public TProductController(CommerceMSContext context)
			{
				_context = context;
			}

			// GET: /TProduct
			[HttpGet]
			public ActionResult<IEnumerable<TProduct>> Get()
			{
				return _context.TProducts.ToList();
			}

			// GET: /TProduct/{id}
			[HttpGet("{id}")]
			public ActionResult<TProduct> Get(int id)
			{
				var product = _context.TProducts.Find(id);

				if (product == null)
				{
					return NotFound();
				}

				return product;
			}

			// POST: /TProduct
			[HttpPost]
			public ActionResult<TProduct> Post(TProduct product)
			{
				_context.TProducts.Add(product);
				_context.SaveChanges();

				return CreatedAtAction(nameof(Get), new { id = product.ProductId }, product);
			}

			// PUT: /TProduct/{id}
			[HttpPut("{id}")]
			public IActionResult Put(int id, TProduct product)
			{
				if (id != product.ProductId)
				{
					return BadRequest();
				}

				_context.Entry(product).State = EntityState.Modified;
				_context.SaveChanges();

				return NoContent();
			}

			// DELETE: /TProduct/{id}
			[HttpDelete("{id}")]
			public IActionResult Delete(int id)
			{
				var product = _context.TProducts.Find(id);

				if (product == null)
				{
					return NotFound();
				}

				_context.TProducts.Remove(product);
				_context.SaveChanges();

				return NoContent();
			}
		}
	}


