﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MongoCRUD.Models;

namespace MongoCRUD.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class EmployeesController : ControllerBase
	{
		private readonly EmployeeRepository _repository;

		public EmployeesController(EmployeeRepository repository)
		{
			_repository = repository;
		}

		[HttpGet]
		public async Task<IActionResult> GetAllEmployees()
		{
			var employees = await _repository.GetAllEmployees();
			return Ok(employees);
		}

		[HttpGet("{id:length(24)}")]
		public async Task<IActionResult> GetEmployee(string id)
		{
			var employee = await _repository.GetEmployee(id);

			if (employee == null)
			{
				return NotFound();
			}

			return Ok(employee);
		}

		[HttpPost]
		public async Task<IActionResult> CreateEmployee(Employee employee)
		{
			await _repository.Create(employee);

			return CreatedAtAction(nameof(GetEmployee), new { id = employee.EmployeeId }, employee);
		}

		[HttpPut("{id:length(24)}")]
		public async Task<IActionResult> UpdateEmployee(string id, Employee employee)
		{
			var employeeToUpdate = await _repository.GetEmployee(id);

			if (employeeToUpdate == null)
			{
				return NotFound();
			}

			employee.EmployeeId = employeeToUpdate.EmployeeId;

			var result = await _repository.Update(id, employee);

			if (!result)
			{
				return StatusCode(500);
			}

			return NoContent();
		}

		[HttpDelete("{id:length(24)}")]
		public async Task<IActionResult> DeleteEmployee(string id)
		{
			var employeeToDelete = await _repository.GetEmployee(id);

			if (employeeToDelete == null)
			{
				return NotFound();
			}

			var result = await _repository.Delete(id);

			if (!result)
			{
				return StatusCode(500);
			}

			return NoContent();
		}
	}
}
