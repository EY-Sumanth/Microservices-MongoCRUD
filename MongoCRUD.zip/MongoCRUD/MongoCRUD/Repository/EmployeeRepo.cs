﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace MongoCRUD.Models
{
	public class EmployeeRepository
	{
		private readonly IMongoCollection<Employee> _employees;

		//public EmployeeRepository(string connectionString, string databaseName)
		//{
		//	var client = new MongoClient(connectionString);
		//	var database = client.GetDatabase(databaseName);
		//	_employees = database.GetCollection<Employee>("Employee");
		//}
		public EmployeeRepository(IOptions<EmployeeStoreSettting>setting)
		{
			var client = new MongoClient(setting.Value.ConnectionString);
			var database = client.GetDatabase(setting.Value.DatabaseName);
			_employees = database.GetCollection<Employee>(setting.Value.EmployeeCollectionName); 
		}

		public async Task<List<Employee>> GetAllEmployees()
		{
			return await _employees.Find(employee => true).ToListAsync();
		}

		public async Task<Employee> GetEmployee(string id)
		{
			return await _employees.Find<Employee>(employee => employee.EmployeeId == id).FirstOrDefaultAsync();
		}

		public async Task Create(Employee employee)
		{
			await _employees.InsertOneAsync(employee);
		}

		public async Task<bool> Update(string id, Employee employee)
		{
			var result = await _employees.ReplaceOneAsync(employee => employee.EmployeeId == id, employee);
			return result.IsAcknowledged && result.ModifiedCount > 0;
		}

		public async Task<bool> Delete(string id)
		{
			var result = await _employees.DeleteOneAsync(employee => employee.EmployeeId == id);
			return result.IsAcknowledged && result.DeletedCount > 0;
		}
	}
}
