﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace MongoCRUD.Models
{
	public class Employee
	{
		[BsonId]
		[BsonRepresentation(BsonType.ObjectId)]

		public string? id { get; set; }
		

		public string EmployeeId { get; set; }



		public string? Employeename { get; set; }

		public string? EmployeeAge { get; set; }

		public string? EmployeeDesignation { get; set; }

		public string? EmployeeSalary { get; set;}

		public string? EmployeeAddress { get; set;}

		public string? Employeegender { get; set;}

		

	}
}
