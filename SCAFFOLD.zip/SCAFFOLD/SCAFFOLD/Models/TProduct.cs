﻿using System;
using System.Collections.Generic;

namespace SCAFFOLD.Models
{
    public partial class TProduct
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = null!;
        public string ProductDescription { get; set; } = null!;
        public string Stock { get; set; } = null!;
        public DateTime ManufactureDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int CategoryId { get; set; }
        public int CompanyId { get; set; }

        public virtual TCategory Category { get; set; } = null!;
    }
}
