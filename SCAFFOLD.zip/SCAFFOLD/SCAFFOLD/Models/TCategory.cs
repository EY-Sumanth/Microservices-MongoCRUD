﻿using System;
using System.Collections.Generic;

namespace SCAFFOLD.Models
{
    public partial class TCategory
    {
        public TCategory()
        {
            TProducts = new HashSet<TProduct>();
        }

        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = null!;

        public virtual ICollection<TProduct> TProducts { get; set; }
    }
}
