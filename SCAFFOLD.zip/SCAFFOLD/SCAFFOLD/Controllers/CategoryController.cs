﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SCAFFOLD.Models;

namespace SCAFFOLD.Controllers
{
	
		public class TCategoryController : Controller
	{
			private readonly EcommerceDBContext _context;

			public TCategoryController(EcommerceDBContext context)
			{
				_context = context;
			}

			// GET: TCategory
			public async Task<IActionResult> Index()
			{
				return View(await _context.TCategories.ToListAsync());
			}

			// GET: TCategory/Details/5
			public async Task<IActionResult> Details(int? id)
			{
				if (id == null)
				{
					return NotFound();
				}

				var tCategory = await _context.TCategories
					.Include(t => t.TProducts)
					.FirstOrDefaultAsync(m => m.CategoryId == id);
				if (tCategory == null)
				{
					return NotFound();
				}

				return View(tCategory);
			}

			// GET: TCategory/Create
			public IActionResult Create()
			{
				return View();
			}

			// POST: TCategory/Create
			[HttpPost]
			[ValidateAntiForgeryToken]
			public async Task<IActionResult> Create([Bind("CategoryId,CategoryName")] TCategory tCategory)
			{
				if (ModelState.IsValid)
				{
					_context.Add(tCategory);
					await _context.SaveChangesAsync();
					return RedirectToAction(nameof(Index));
				}
				return View(tCategory);
			}

			// GET: TCategory/Edit/5
			public async Task<IActionResult> Edit(int? id)
			{
				if (id == null)
				{
					return NotFound();
				}

				var tCategory = await _context.TCategories.FindAsync(id);
				if (tCategory == null)
				{
					return NotFound();
				}
				return View(tCategory);
			}

			// POST: TCategory/Edit/5
			[HttpPost]
			[ValidateAntiForgeryToken]
			public async Task<IActionResult> Edit(int id, [Bind("CategoryId,CategoryName")] TCategory tCategory)
			{
				if (id != tCategory.CategoryId)
				{
					return NotFound();
				}

				if (ModelState.IsValid)
				{
					try
					{
						_context.Update(tCategory);
						await _context.SaveChangesAsync();
					}
					catch (DbUpdateConcurrencyException)
					{
						if (!TCategoryExists(tCategory.CategoryId))
						{
							return NotFound();
						}
						else
						{
							throw;
						}
					}
					return RedirectToAction(nameof(Index));
				}
				return View(tCategory);
			}

			// GET: TCategory/Delete/5
			public async Task<IActionResult> Delete(int? id)
			{
				if (id == null)
				{
					return NotFound();
				}

				var tCategory = await _context.TCategories
					.FirstOrDefaultAsync(m => m.CategoryId == id);
				if (tCategory == null)
				{
					return NotFound();
				}

				return View(tCategory);
			}

			// POST: TCategory/Delete/5
			[HttpPost, ActionName("Delete")]
			[ValidateAntiForgeryToken]
			public async Task<IActionResult> DeleteConfirmed(int id)
			{
				var tCategory = await _context.TCategories.FindAsync(id);
				_context.TCategories.Remove(tCategory);
				await _context.SaveChangesAsync();
				return RedirectToAction(nameof(Index));
			}

			private bool TCategoryExists(int id)
			{
				return _context.TCategories.Any(e => e.CategoryId == id);
			}
		}
	}


