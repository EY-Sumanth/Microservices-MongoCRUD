﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SCAFFOLD.Models;

namespace SCAFFOLD.Controllers
{
	
		[ApiController]
		[Route("api/products")]
		public class ProductController : ControllerBase
		{
			private readonly EcommerceDBContext _context;

			public ProductController(EcommerceDBContext context)
			{
				_context = context;
			}

			// GET: api/products
			[HttpGet]
			public ActionResult<IEnumerable<TProduct>> GetProducts()
			{
				return _context.TProducts.Include(p => p.Category).ToList();
			}

			// GET: api/products/5
			[HttpGet("{id}")]
			public ActionResult<TProduct> GetProduct(int id)
			{
				var product = _context.TProducts.Include(p => p.Category).FirstOrDefault(p => p.ProductId == id);

				if (product == null)
				{
					return NotFound();
				}

				return product;
			}

			// POST: api/products
			[HttpPost]
			public ActionResult<TProduct> CreateProduct(TProduct product)
			{
				_context.TProducts.Add(product);
				_context.SaveChanges();

				return CreatedAtAction(nameof(GetProduct), new { id = product.ProductId }, product);
			}

			// PUT: api/products/5
			[HttpPut("{id}")]
			public IActionResult UpdateProduct(int id, TProduct product)
			{
				if (id != product.ProductId)
				{
					return BadRequest();
				}

				_context.Entry(product).State = EntityState.Modified;
				_context.SaveChanges();

				return NoContent();
			}

			// DELETE: api/products/5
			[HttpDelete("{id}")]
			public IActionResult DeleteProduct(int id)
			{
				var product = _context.TProducts.Find(id);

				if (product == null)
				{
					return NotFound();
				}

				_context.TProducts.Remove(product);
				_context.SaveChanges();

				return NoContent();
			}
		}
	}


